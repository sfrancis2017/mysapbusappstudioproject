sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'devtestproject/employees/test/integration/FirstJourney',
		'devtestproject/employees/test/integration/pages/EmployeeList',
		'devtestproject/employees/test/integration/pages/EmployeeObjectPage'
    ],
    function(JourneyRunner, opaJourney, EmployeeList, EmployeeObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('devtestproject/employees') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheEmployeeList: EmployeeList,
					onTheEmployeeObjectPage: EmployeeObjectPage
                }
            },
            opaJourney.run
        );
    }
);