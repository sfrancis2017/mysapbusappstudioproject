sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'devtestproject/address/test/integration/FirstJourney',
		'devtestproject/address/test/integration/pages/AddressList',
		'devtestproject/address/test/integration/pages/AddressObjectPage'
    ],
    function(JourneyRunner, opaJourney, AddressList, AddressObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('devtestproject/address') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheAddressList: AddressList,
					onTheAddressObjectPage: AddressObjectPage
                }
            },
            opaJourney.run
        );
    }
);