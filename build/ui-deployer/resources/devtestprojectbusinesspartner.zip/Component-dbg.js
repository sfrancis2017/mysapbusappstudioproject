sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("devtestproject.businesspartner.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);