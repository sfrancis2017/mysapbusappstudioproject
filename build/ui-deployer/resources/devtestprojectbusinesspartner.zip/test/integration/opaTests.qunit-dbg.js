sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'devtestproject/businesspartner/test/integration/FirstJourney',
		'devtestproject/businesspartner/test/integration/pages/BusinessPartnerList',
		'devtestproject/businesspartner/test/integration/pages/BusinessPartnerObjectPage'
    ],
    function(JourneyRunner, opaJourney, BusinessPartnerList, BusinessPartnerObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('devtestproject/businesspartner') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheBusinessPartnerList: BusinessPartnerList,
					onTheBusinessPartnerObjectPage: BusinessPartnerObjectPage
                }
            },
            opaJourney.run
        );
    }
);