sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'devtestproject/purchaseorderitems/test/integration/FirstJourney',
		'devtestproject/purchaseorderitems/test/integration/pages/PurchaseOrderItemsList',
		'devtestproject/purchaseorderitems/test/integration/pages/PurchaseOrderItemsObjectPage'
    ],
    function(JourneyRunner, opaJourney, PurchaseOrderItemsList, PurchaseOrderItemsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('devtestproject/purchaseorderitems') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onThePurchaseOrderItemsList: PurchaseOrderItemsList,
					onThePurchaseOrderItemsObjectPage: PurchaseOrderItemsObjectPage
                }
            },
            opaJourney.run
        );
    }
);